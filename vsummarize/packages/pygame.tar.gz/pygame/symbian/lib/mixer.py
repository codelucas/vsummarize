from pygame_mixer import * 
import pygame_mixer_music as music